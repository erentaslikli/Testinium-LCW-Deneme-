package Test1;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    WebDriver webDriver;
    WebDriverWait webDriverWait;

    public LoginPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.webDriver = new WebDriverWait(webDriver, 30,  150);
    }

    public void TestClass(String username, String password) {


        webDriver.get("https://www.lcwaikiki.com/tr-TR/TR");
        Assert.assertEquals("LC Waikiki Logo", webDriver.getTitle());
        webDriverWait.until(ExpectedConditions.elementToBeClickable(By.className("btn-group header-user dropdown"))).click();
        Assert.assertEquals("btn-group header-user dropdown", webDriver.getTitle());
        webDriver.findElement(By.id("LoginEmail")).clear();
        webDriver.findElement(By.id("LoginEmail")).sendKeys(username);
        webDriver.findElement(By.id("Password")).clear();
        webDriver.findElement(By.id("Password")).sendKeys(password);
        webDriverWait.until(ExpectedConditions.elementToBeClickable(By.id("loginLink"))).click();


        WebElement searchData = webDriver.findElement(By.id("searchData"));
        searchData.sendKeys("Bilgisayar");
        searchData.sendKeys(Keys.ENTER);


    }
}